*/Creating Tables:
1) Patients table
2) Doctors table
3) Appointments table
4)


*/Patients table:

CREATE TABLE Patients 
(
    PatientID 	INT 			PRIMARY KEY IDENTITY(1,1),
    Name		NVARCHAR(100) 	NOT NULL,
    DOB 		DATE 			NOT NULL,
    Gender 		CHAR(1) 		CHECK (Gender IN ('M', 'F', 'O')),
    Phone 		NVARCHAR(15) 	UNIQUE,
    Address 	NVARCHAR(255)	NOT NULL,
    CreatedAt 	DATETIME 		DEFAULT GETDATE()
);

INSERT INTO Patients (Name, DOB, Gender, Phone, Address) 
VALUES 
('Amit Sharma',  '1988-03-12', 'M', '9876543210', 'Delhi'),
('Priya Verma',  '1995-07-25', 'F', '8765432109', 'Mumbai'),
('Rahul Mehta',  '1992-01-18', 'M', '9988776655', 'Bangalore'),
('Neha Kapoor',  '1987-09-30', 'F', '8899776655', 'Chennai'),
('Vikram Singh', '1990-12-05', 'M', '7788996655', 'Hyderabad'),
('Sanya Iyer',   '1998-05-22', 'F', '7676889999', 'Kolkata'),
('Rajesh Khanna','1985-11-08', 'M', '9876061234', 'Pune'),
('Sneha Joshi',  '1993-04-16', 'F', '8547563210', 'Ahmedabad'),
('Arjun Reddy',  '1996-09-29', 'M', '9321456789', 'Chandigarh'),
('Kiran Rao',    '1982-07-19', 'M', '9012345678', 'Lucknow');

/Doctors Table


CREATE TABLE Doctors
 (
    DoctorID 		INT				 PRIMARY KEY	 IDENTITY(1,1),
    Name 			NVARCHAR(100) 	 NOT NULL,
    Specialization	NVARCHAR(100)	 NOT NULL,
    Phone 			NVARCHAR(15) 	 UNIQUE,
    Experience 		INT 			 CHECK (Experience >= 0),
    CreatedAt 		DATETIME 		 DEFAULT GETDATE()
);

INSERT INTO Doctors (Name, Specialization, Phone, Experience) 
VALUES 
('Dr. Anil Desai', 	'Cardiologist',			'9112233445', 12),
('Dr. Meera Nair', 	'Neurologist',			'9223344556', 15),
('Dr. Karthik Reddy', 	'Orthopedic',       '9334455667', 10),
('Dr. Priyanka Bansal', 'Pediatrician',      '9445566778', 8),
('Dr. Manish Verma', 	'Dermatologist',     '9556677889', 9),
('Dr. Swati Sharma',   	'ENT Specialist',    '9667788990', 11),
('Dr. Suresh Kumar', 	'General Physician', '9778899001', 20),
('Dr. Kavita Iyer', 	'Gynecologist',      '9889900112', 14),
('Dr. Raj Malhotra', 	'Oncologist',        '9990011223', 18),
('Dr. Arvind Joshi', 	'Psychiatrist',      '9001122334', 7);


/* Appointments Table*/

CREATE TABLE Appointments 
(
    AppointmentID		INT			 PRIMARY KEY IDENTITY(1,1),
    PatientID			INT			 NOT NULL,
    DoctorID			INT			 NOT NULL,
    AppointmentDate	    DATETIME	 NOT NULL,
    Status				NVARCHAR(50) CHECK (Status IN ('Scheduled', 'Completed', 'Cancelled')),
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID) ON DELETE CASCADE,
    FOREIGN KEY (DoctorID)  REFERENCES Doctors(DoctorID) ON DELETE CASCADE
);






INSERT INTO Appointments (PatientID, DoctorID, AppointmentDate, Status) 
VALUES 
(1,  1, '2024-03-01 09:00:00', 'Scheduled'),
(2,  2, '2024-03-02 10:30:00', 'Completed'),
(3,  3, '2024-03-03 11:00:00', 'Scheduled'),
(4,  4, '2024-03-04 14:00:00', 'Cancelled'),
(5,  5, '2024-03-05 16:00:00', 'Scheduled'),
(6,  6, '2024-03-06 09:30:00', 'Completed'),
(7,  7, '2024-03-07 12:00:00', 'Scheduled'),
(8,  8, '2024-03-08 15:00:00', 'Scheduled'),
(9,  9, '2024-03-09 17:30:00', 'Completed'),
(10, 10,'2024-03-10 10:00:00', 'Scheduled'),
(1,  3, '2024-03-11 11:30:00', 'Cancelled'),
(2,  5, '2024-03-12 14:45:00', 'Scheduled'),
(3,  7, '2024-03-13 16:15:00', 'Completed'),
(4,  9, '2024-03-14 09:45:00', 'Scheduled'),
(5,  2, '2024-03-15 12:30:00', 'Scheduled');

/*Medical Records Table*/

CREATE TABLE MedicalRecords 
(
    RecordID 	 INT 			PRIMARY KEY IDENTITY(1,1),
    PatientID	 INT    		NOT NULL,
    DoctorID 	 INT    		NOT NULL,
    Diagnosis 	 NVARCHAR(255) NOT NULL,
    Prescription NVARCHAR(255) NOT NULL,
    RecordDate   DATETIME 	DEFAULT GETDATE(),
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID) ON DELETE CASCADE,
    FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID) ON DELETE CASCADE
);
