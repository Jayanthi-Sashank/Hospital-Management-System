/* Queries */

1) Retreive all the patients :

select * from Patients

2) Get patient details from their phone number:

select * from Patients
where
Phone='8765432109'

3)List of Doctors and their Specializations:

Select Name,Specialization 
from Doctors

4)Find Appointments scheduled today:

SELECT * FROM Appointments
WHERE CAST(AppointmentDate AS DATE) = CAST(GETDATE() AS DATE);

5) FInd Appointments completed on '2024-03-02'

Select * from Appointments
where Cast(AppointmentDate as DATE)='2024-03-02'

6) Retrieve Appointment details with patient and Doctor info:

select  a.AppointmentID,a.AppointmentDate,p.Name as PatientName ,a.PatientID,d.Name as DoctorName,d.specialization,a.Status
from Appointments a
join Patients p on p.PatientID=a.PatientID
join Doctors d  on d.DoctorID=a.DoctorID

7)Count Appointments by status:

select Status,count(*) as NoOfAppointments
from Appointments
group by Status

8)Find Patients with more than 2 Appointments:

select PatientID, count(*) as 'Number Of Appointments'
from Appointments 
group By PatientID
having count(*)>2

9)Get Last Appointment for each Patient:

select * from Patients
select * from Appointments

select a.PatientID,p.name,max(a.AppointmentDate) as 'Last Appointment Date'
from Patients p
join Appointments a on p.PatientID=a.PatientID
group By p.name,a.PatientID

10) Count appointment for each doctor:

select d.name, count(a.AppointmentID) as 'Number of Appointments for each doctor'
from Appointments a
left join Doctors d on a.DoctorID=d.DoctorID
group by d.name

11)Find the most popular doctor based on appointments

select * from Patients
select * from Appointments
select * from Doctors

select d.name, count(*) as maxappointmentsforeachdoctor
from Appointments a
left join Doctors d on a.DoctorID=d.DoctorID
group by d.name
having count(*)  = 
				(
				  select max(maxappointmentsforeachdoctor)
				  from 
					(
						select a.doctorID ,count(*) as maxappointmentsforeachdoctor
						from appointments a
						group by a.DoctorID
					)as MaximumAppointments
				)

Alternative approach using CTE:

with CTE as 
(
 select d.name, count(*) as numberofappointments
 from appointments a
 join Doctors d on a.DoctorID=d.DoctorID
 group by d.name
)
select name, numberofappointments
from CTE 
where numberofappointments=
						(
						 select max(numberofappointments)
						 from CTE
						 )
						 
Alternative approach using window functions:

select name, numberofappointments
from 
(
select d.name,count(*) as numberofappointments, Dense_Rank() over(order by count(*) desc)as RANK
from appointments a
join doctors d on a.DoctorID=d.DoctorID
group by d.name
)as maximumrankeddoctor
where RANK=1

12) Rank patients by number of appointments:

select p.name, count(*)as numberofappointments, dense_rank() over(order by count(*) desc)as RANK
from Patients p
join Appointments a on a.PatientID=p.PatientID
group by p.name

13)Find  running total appointments per day

select * from appointments

select appointmentdate, count(*) as Dailyappointments, sum(count(*)) over(order by appointmentdate)as RUNNINGTOTAL
from appointments
group by appointmentdate

14) Stored Procedure to update Appointment status automatically

CREATE PROCEDURE UpdateAppointmentStatus
AS
BEGIN
    UPDATE Appointments
    SET Status = 'Completed'
    WHERE AppointmentDate < GETDATE() AND Status = 'Scheduled';
END;
GO
EXEC UpdateAppointmentStatus;

15) Index on Appointments for faster searches

CREATE INDEX idx_PatientID ON Appointments (PatientID);
CREATE INDEX idx_DoctorID ON Appointments (DoctorID);
CREATE INDEX idx_AppointmentDate ON Appointments (AppointmentDate);

